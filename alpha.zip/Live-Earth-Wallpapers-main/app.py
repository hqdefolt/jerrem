#!/usr/bin/env python3
import numpy
import bs4
import os
import PIL
import requests
from liewa.liewa_gui.main import startup
import liewa.liewa_cli

if __name__ == "__main__":
    startup()
